# Budget Tracker Starter Code
I have fixed up the code so you are now allowed to track your Deposits and withdrawals with or withouth internet connection.

GIVEN a budget tracker without an internet connection
WHEN the user inputs an expense or deposit
THEN they will receive a notification that they have added an expense or deposit
WHEN the user reestablishes an internet connection
THEN the deposits or expenses added while they were offline are added to their transaction history and their totals are updated